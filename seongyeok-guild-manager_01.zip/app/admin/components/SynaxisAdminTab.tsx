"use client";

import { useState, useEffect } from "react";
import { supabase } from "@/lib/supabase";

export default function SynaxisAdminTab() {
  const [diffList, setDiffList] = useState<any[]>([]);
  const [contentName, setContentName] = useState("글라스 기브넨 레이드");
  const [diffName, setDiffName] = useState("어려움");
  const [recCp, setRecCp] = useState<number | "">(15000);
  const [recMr, setRecMr] = useState<number | "">(1500);
  const [overCp, setOverCp] = useState<number | "">(25000);
  const [overMr, setOverMr] = useState<number | "">(2500);

  useEffect(() => {
    fetchDifficulties();
  }, []);

  const fetchDifficulties = async () => {
    const { data } = await supabase.from("nexus_content_difficulties").select("*").order("id", { ascending: false });
    if (data) setDiffList(data);
  };

  const handleSaveDifficulty = async (e: React.FormEvent) => {
    e.preventDefault();
    const { error } = await supabase.from("nexus_content_difficulties").upsert(
      [
        {
          content_name: contentName,
          difficulty_name: diffName,
          rec_combat_power: Number(recCp) || 0,
          rec_magic_resist: Number(recMr) || 0,
          overpower_combat_power: Number(overCp) || 0,
          overpower_magic_resist: Number(overMr) || 0,
        },
      ],
      { onConflict: "content_name,difficulty_name" }
    );

    if (error) return alert("저장 실패: " + error.message);
    alert("난이도 요구 스탯이 등록되어 길드 버스 엔진에 실시간 연동되었습니다.");
    fetchDifficulties();
  };

  return (
    <div className="space-y-6">
      <div className="border-b border-zinc-800 pb-4">
        <h2 className="text-xl font-bold text-[#e6c788]">⚔️ 시낙시스 난이도 & 버스 요구 스탯 설정</h2>
        <p className="text-xs text-zinc-400 mt-1">어비스/레이드 난이도별 최소 권장·압도 전투력(CP)과 마법 저항력을 연동합니다.</p>
      </div>

      <form onSubmit={handleSaveDifficulty} className="bg-[#252528] p-4 rounded-xl border border-zinc-700 space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs text-zinc-300 font-bold mb-1">컨텐츠 명칭</label>
            <input
              type="text"
              value={contentName}
              onChange={(e) => setContentName(e.target.value)}
              className="w-full bg-[#121212] text-xs text-white p-2.5 rounded-lg border border-zinc-700 outline-none"
            />
          </div>
          <div>
            <label className="block text-xs text-zinc-300 font-bold mb-1">난이도 명칭</label>
            <input
              type="text"
              value={diffName}
              onChange={(e) => setDiffName(e.target.value)}
              className="w-full bg-[#121212] text-xs text-white p-2.5 rounded-lg border border-zinc-700 outline-none"
            />
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div>
            <label className="block text-[11px] text-amber-400 font-bold mb-1">권장 전투력 (CP)</label>
            <input
              type="number"
              value={recCp}
              onChange={(e) => setRecCp(Number(e.target.value))}
              className="w-full bg-[#121212] text-xs text-amber-400 font-bold p-2 rounded-lg border border-zinc-700 outline-none"
            />
          </div>
          <div>
            <label className="block text-[11px] text-cyan-400 font-bold mb-1">권장 마도저항</label>
            <input
              type="number"
              value={recMr}
              onChange={(e) => setRecMr(Number(e.target.value))}
              className="w-full bg-[#121212] text-xs text-cyan-400 font-bold p-2 rounded-lg border border-zinc-700 outline-none"
            />
          </div>
          <div>
            <label className="block text-[11px] text-rose-400 font-bold mb-1">압도 전투력 (CP)</label>
            <input
              type="number"
              value={overCp}
              onChange={(e) => setOverCp(Number(e.target.value))}
              className="w-full bg-[#121212] text-xs text-rose-400 font-bold p-2 rounded-lg border border-zinc-700 outline-none"
            />
          </div>
          <div>
            <label className="block text-[11px] text-purple-400 font-bold mb-1">압도 마도저항</label>
            <input
              type="number"
              value={overMr}
              onChange={(e) => setOverMr(Number(e.target.value))}
              className="w-full bg-[#121212] text-xs text-purple-400 font-bold p-2 rounded-lg border border-zinc-700 outline-none"
            />
          </div>
        </div>

        <button type="submit" className="w-full bg-[#e6c788] hover:bg-[#d8b572] text-black font-bold text-xs py-3 rounded-lg transition cursor-pointer">
          난이도 요구 스탯 저장 / 업서트
        </button>
      </form>

      <div className="bg-[#252528] rounded-xl border border-zinc-700 p-4 divide-y divide-zinc-800">
        {diffList.map((d) => (
          <div key={d.id} className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
            <div>
              <span className="text-white font-bold">{d.content_name}</span> - <span className="text-amber-400 font-bold">{d.difficulty_name}</span>
              <div className="text-zinc-400 text-[11px] mt-0.5">
                권장: CP {d.rec_combat_power?.toLocaleString()} / 마저 {d.rec_magic_resist?.toLocaleString()} | 압도: CP {d.overpower_combat_power?.toLocaleString()} / 마저 {d.overpower_magic_resist?.toLocaleString()}
              </div>
            </div>
            <button
              onClick={async () => {
                if (!confirm("삭제하시겠습니까?")) return;
                await supabase.from("nexus_content_difficulties").delete().eq("id", d.id);
                fetchDifficulties();
              }}
              className="text-rose-400 font-bold self-end sm:self-center hover:underline cursor-pointer"
            >
              삭제
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}