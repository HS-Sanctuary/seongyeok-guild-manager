"use client";

import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/lib/supabase";
import ClassIcon from "@/components/common/ClassIcon";

interface TaskItem {
  id: string | number;
  name: string;
  type: "daily" | "weekly" | "repeat";
  repeat_cycle?: "daily" | "weekly";
  max_count: number;
}

// nexus_contents 테이블 스키마 1:1 매칭 인터페이스
interface NexusContentItem {
  id: number | string;
  type: "abyss" | "raid" | string;
  name: string;
  short_name?: string;
  is_weekend?: boolean;
  is_active?: boolean;
  mobile_name?: string | null;
}

interface ClassItem {
  id: string | number;
  name: string;
  role: "근딜" | "원딜" | "탱커" | "힐러" | "서포터";
}

// nexus_contents DB 기본 데이터 (image_bef124.png 스키마와 100% 동일)
const DEFAULT_CONTENTS: NexusContentItem[] = [
  { id: 4, type: "abyss", name: "어비스 - 허상의 정박지", short_name: "허상", is_weekend: false, is_active: true },
  { id: 5, type: "abyss", name: "어비스 - 광기의 동굴", short_name: "동굴", is_weekend: false, is_active: true },
  { id: 6, type: "abyss", name: "어비스 - 흩어진 물길", short_name: "물길", is_weekend: false, is_active: true },
  { id: 7, type: "abyss", name: "주말에는 어비스", short_name: "주말", is_weekend: true, is_active: true, mobile_name: "[주말] 어비스" },
  { id: 8, type: "raid", name: "레이드 - 카브락", short_name: "카브", is_weekend: false, is_active: true },
  { id: 9, type: "raid", name: "레이드 - 화이트 서큐버스", short_name: "서큐", is_weekend: false, is_active: true, mobile_name: "화이트 서큐" },
  { id: 10, type: "raid", name: "레이드 - 에이렐", short_name: "에이렐", is_weekend: false, is_active: true },
  { id: 11, type: "raid", name: "주말에는 레이드", short_name: "주말", is_weekend: true, is_active: true, mobile_name: "[주말] 레이드" },
];

const DEFAULT_TASKS: TaskItem[] = [
  { id: "t-1", name: "필드 보스 처치", type: "daily", max_count: 1 },
  { id: "t-2", name: "여신상 공물 바치기", type: "daily", max_count: 1 },
  { id: "t-3", name: "주간 어비스 클리어", type: "weekly", max_count: 1 },
  { id: "t-4", name: "주간 레이드 클리어", type: "weekly", max_count: 1 },
  { id: "t-5", name: "소환의 결계", type: "repeat", repeat_cycle: "weekly", max_count: 7 },
  { id: "t-6", name: "창백한 산", type: "repeat", repeat_cycle: "weekly", max_count: 5 },
];

const DEFAULT_CLASSES: ClassItem[] = [
  { id: "c-1", name: "검술사", role: "근딜" },
  { id: "c-2", name: "격투가", role: "근딜" },
  { id: "c-3", name: "궁수", role: "원딜" },
  { id: "c-4", name: "기사", role: "탱커" },
  { id: "c-5", name: "대검전사", role: "근딜" },
  { id: "c-6", name: "댄서", role: "근딜" },
  { id: "c-7", name: "도적", role: "근딜" },
  { id: "c-8", name: "듀얼블레이드", role: "근딜" },
  { id: "c-9", name: "마법사", role: "원딜" },
  { id: "c-10", name: "빙결술사", role: "탱커" },
  { id: "c-11", name: "사제", role: "힐러" },
  { id: "c-12", name: "석궁사수", role: "원딜" },
  { id: "c-13", name: "수도사", role: "힐러" },
  { id: "c-14", name: "악사", role: "원딜" },
  { id: "c-15", name: "암흑술사", role: "원딜" },
  { id: "c-16", name: "음유시인", role: "서포터" },
  { id: "c-17", name: "장궁병", role: "원딜" },
  { id: "c-18", name: "전격술사", role: "원딜" },
  { id: "c-19", name: "전사", role: "탱커" },
  { id: "c-20", name: "화염술사", role: "원딜" },
  { id: "c-21", name: "힐러", role: "힐러" },
];

export default function KronosAdminTab() {
  const [subTab, setSubTab] = useState<"tasks" | "dungeons" | "classes">("dungeons");
  const [loading, setLoading] = useState(false);

  // 데이터 상태
  const [tasks, setTasks] = useState<TaskItem[]>(DEFAULT_TASKS);
  const [dungeons, setDungeons] = useState<NexusContentItem[]>(DEFAULT_CONTENTS);
  const [classes, setClasses] = useState<ClassItem[]>(DEFAULT_CLASSES);

  // 폼 상태 - 숙제
  const [newDailyName, setNewDailyName] = useState("");
  const [newWeeklyName, setNewWeeklyName] = useState("");
  const [newRepeatName, setNewRepeatName] = useState("");
  const [newRepeatCycle, setNewRepeatCycle] = useState<"daily" | "weekly">("weekly");
  const [newRepeatMax, setNewRepeatMax] = useState<number>(7);

  // 폼 상태 - 어비스 / 레이드
  const [newAbyssName, setNewAbyssName] = useState("");
  const [newRaidName, setNewRaidName] = useState("");

  // 폼 상태 - 클래스
  const [newClassName, setNewClassName] = useState("");

  // 수정 모달 상태
  const [editingItem, setEditingItem] = useState<{ type: "task" | "dungeon" | "class"; data: any } | null>(null);

  // 데이터 수집 (nexus_contents 테이블 정밀 연동)
  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const [{ data: tData }, { data: dData }, { data: cData }] = await Promise.all([
        supabase.from("nexus_tasks").select("*").order("id"),
        supabase.from("nexus_contents").select("*").order("id"),
        supabase.from("nexus_classes").select("*").order("id"),
      ]);

      if (tData && tData.length > 0) setTasks(tData);
      if (dData && dData.length > 0) setDungeons(dData);
      if (cData && cData.length > 0) setClasses(cData);
    } catch (err) {
      console.error("어드민 데이터 동기화 에러 (기본값 로드):", err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // --- 숙제 관리 액션 ---
  const handleAddTask = async (type: "daily" | "weekly" | "repeat", name: string, maxCount = 1, cycle?: "daily" | "weekly") => {
    if (!name.trim()) return alert("숙제 명칭을 입력해 주세요.");
    const newItem: TaskItem = {
      id: Date.now(),
      name: name.trim(),
      type,
      max_count: maxCount,
      repeat_cycle: cycle || "weekly",
    };

    setTasks((prev) => [...prev, newItem]);
    if (type === "daily") setNewDailyName("");
    if (type === "weekly") setNewWeeklyName("");
    if (type === "repeat") setNewRepeatName("");

    await supabase.from("nexus_tasks").insert([
      { name: name.trim(), type, max_count: maxCount, repeat_cycle: cycle || "weekly", is_active: true }
    ]);
  };

  const handleDeleteTask = async (id: string | number) => {
    if (!confirm("해당 숙제 항목을 삭제하시겠습니까?")) return;
    setTasks((prev) => prev.filter((t) => t.id !== id));
    await supabase.from("nexus_tasks").delete().eq("id", id);
  };

  // --- 어비스/레이드 관리 액션 (nexus_contents 스키마 저장) ---
  const handleAddDungeon = async (contentType: "abyss" | "raid", name: string) => {
    if (!name.trim()) return alert("던전 명칭을 입력해 주세요.");
    const isWeekend = name.includes("주말");
    const shortName = name.replace("어비스 - ", "").replace("레이드 - ", "").substring(0, 4);

    const newItem: NexusContentItem = {
      id: Date.now(),
      name: name.trim(),
      type: contentType,
      short_name: shortName,
      is_weekend: isWeekend,
      is_active: true,
    };

    setDungeons((prev) => [...prev, newItem]);
    if (contentType === "abyss") setNewAbyssName("");
    if (contentType === "raid") setNewRaidName("");

    await supabase.from("nexus_contents").insert([
      {
        name: name.trim(),
        type: contentType,
        short_name: shortName,
        is_weekend: isWeekend,
        is_active: true,
      }
    ]);
  };

  const handleDeleteDungeon = async (id: string | number) => {
    if (!confirm("해당 던전을 삭제하시겠습니까?")) return;
    setDungeons((prev) => prev.filter((d) => d.id !== id));
    await supabase.from("nexus_contents").delete().eq("id", id);
  };

  // --- 클래스 관리 액션 ---
  const handleAddClass = async () => {
    if (!newClassName.trim()) return alert("직업명을 입력해 주세요.");
    const newItem: ClassItem = {
      id: Date.now(),
      name: newClassName.trim(),
      role: "근딜",
    };

    setClasses((prev) => [...prev, newItem]);
    setNewClassName("");

    await supabase.from("nexus_classes").insert([{ name: newClassName.trim(), role: "근딜" }]);
  };

  const handleDeleteClass = async (id: string | number) => {
    if (!confirm("해당 직업을 삭제하시겠습니까?")) return;
    setClasses((prev) => prev.filter((c) => c.id !== id));
    await supabase.from("nexus_classes").delete().eq("id", id);
  };

  // --- 수정 저장 처리 ---
  const handleSaveEdit = async () => {
    if (!editingItem) return;
    const { type, data } = editingItem;

    if (type === "task") {
      setTasks((prev) => prev.map((t) => (t.id === data.id ? data : t)));
      await supabase.from("nexus_tasks").update({ name: data.name, max_count: data.max_count }).eq("id", data.id);
    } else if (type === "dungeon") {
      const isWeekend = data.name.includes("주말") || data.is_weekend;
      const updated = { ...data, is_weekend: isWeekend };
      setDungeons((prev) => prev.map((d) => (d.id === data.id ? updated : d)));
      await supabase.from("nexus_contents").update({ name: data.name, is_weekend: isWeekend }).eq("id", data.id);
    } else if (type === "class") {
      setClasses((prev) => prev.map((c) => (c.id === data.id ? data : c)));
      await supabase.from("nexus_classes").update({ name: data.name, role: data.role }).eq("id", data.id);
    }

    setEditingItem(null);
  };

  return (
    <div className="space-y-6">
      {/* 서브 탭 네비게이션 */}
      <div className="flex items-center gap-6 border-b border-zinc-800 pb-3">
        <button
          onClick={() => setSubTab("tasks")}
          className={`flex items-center gap-2 text-sm font-bold pb-2 transition cursor-pointer border-b-2 ${
            subTab === "tasks"
              ? "text-[#e6c788] border-[#e6c788]"
              : "text-zinc-500 border-transparent hover:text-zinc-300"
          }`}
        >
          📝 숙제 목록 설정
        </button>
        <button
          onClick={() => setSubTab("dungeons")}
          className={`flex items-center gap-2 text-sm font-bold pb-2 transition cursor-pointer border-b-2 ${
            subTab === "dungeons"
              ? "text-[#e6c788] border-[#e6c788]"
              : "text-zinc-500 border-transparent hover:text-zinc-300"
          }`}
        >
          ⚔️ 레이드/어비스 목록 설정
        </button>
        <button
          onClick={() => setSubTab("classes")}
          className={`flex items-center gap-2 text-sm font-bold pb-2 transition cursor-pointer border-b-2 ${
            subTab === "classes"
              ? "text-[#e6c788] border-[#e6c788]"
              : "text-zinc-500 border-transparent hover:text-zinc-300"
          }`}
        >
          🪖 클래스 목록 설정
        </button>
      </div>

      {loading && <div className="text-center py-10 text-xs text-zinc-500 animate-pulse">⏳ nexus_contents 동기화 중...</div>}

      {/* 1. 숙제 목록 설정 */}
      {!loading && subTab === "tasks" && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* 일일 콘텐츠 */}
          <div className="bg-[#121212] border border-zinc-800 rounded-xl p-4 space-y-3 flex flex-col justify-between min-h-[420px]">
            <div className="space-y-3">
              <h3 className="text-sm font-bold text-amber-400 flex items-center gap-1.5">🌼 일일 콘텐츠</h3>
              <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
                {tasks.filter((t) => t.type === "daily").map((t) => (
                  <div key={t.id} className="bg-[#1c1c1e] p-3 rounded-lg border border-zinc-800 flex items-center justify-between text-xs">
                    <span className="font-bold text-zinc-200 truncate">{t.name}</span>
                    <div className="flex items-center gap-1 shrink-0">
                      <button onClick={() => setEditingItem({ type: "task", data: { ...t } })} className="px-2 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded text-[11px] cursor-pointer">수정</button>
                      <button onClick={() => handleDeleteTask(t.id)} className="px-2 py-1 bg-rose-950/60 hover:bg-rose-900 text-rose-400 rounded text-[11px] cursor-pointer">삭제</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="flex gap-1.5 pt-2 border-t border-zinc-800/80">
              <input type="text" placeholder="새 일일 숙제" value={newDailyName} onChange={(e) => setNewDailyName(e.target.value)} className="flex-1 bg-[#1c1c1e] border border-zinc-700 rounded-lg px-2.5 py-2 text-xs text-zinc-200 outline-none focus:border-[#e6c788]" />
              <button onClick={() => handleAddTask("daily", newDailyName, 1)} className="px-3 bg-amber-500/20 hover:bg-amber-500/30 text-amber-400 font-bold rounded-lg text-xs border border-amber-500/40 cursor-pointer">+</button>
            </div>
          </div>

          {/* 주간 콘텐츠 */}
          <div className="bg-[#121212] border border-zinc-800 rounded-xl p-4 space-y-3 flex flex-col justify-between min-h-[420px]">
            <div className="space-y-3">
              <h3 className="text-sm font-bold text-sky-400 flex items-center gap-1.5">🌙 주간 콘텐츠</h3>
              <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
                {tasks.filter((t) => t.type === "weekly").map((t) => (
                  <div key={t.id} className="bg-[#1c1c1e] p-3 rounded-lg border border-zinc-800 flex items-center justify-between text-xs">
                    <span className="font-bold text-zinc-200 truncate">{t.name}</span>
                    <div className="flex items-center gap-1 shrink-0">
                      <button onClick={() => setEditingItem({ type: "task", data: { ...t } })} className="px-2 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded text-[11px] cursor-pointer">수정</button>
                      <button onClick={() => handleDeleteTask(t.id)} className="px-2 py-1 bg-rose-950/60 hover:bg-rose-900 text-rose-400 rounded text-[11px] cursor-pointer">삭제</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="flex gap-1.5 pt-2 border-t border-zinc-800/80">
              <input type="text" placeholder="새 주간 숙제" value={newWeeklyName} onChange={(e) => setNewWeeklyName(e.target.value)} className="flex-1 bg-[#1c1c1e] border border-zinc-700 rounded-lg px-2.5 py-2 text-xs text-zinc-200 outline-none focus:border-[#e6c788]" />
              <button onClick={() => handleAddTask("weekly", newWeeklyName, 1)} className="px-3 bg-sky-500/20 hover:bg-sky-500/30 text-sky-400 font-bold rounded-lg text-xs border border-sky-500/40 cursor-pointer">+</button>
            </div>
          </div>

          {/* 반복 콘텐츠 */}
          <div className="bg-[#121212] border border-zinc-800 rounded-xl p-4 space-y-3 flex flex-col justify-between min-h-[420px]">
            <div className="space-y-3">
              <h3 className="text-sm font-bold text-purple-400 flex items-center gap-1.5">🔄 반복 콘텐츠</h3>
              <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
                {tasks.filter((t) => t.type === "repeat").map((t) => (
                  <div key={t.id} className="bg-[#1c1c1e] p-3 rounded-lg border border-zinc-800 flex items-center justify-between text-xs">
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-[10px] font-bold text-purple-400 border border-purple-500/30 px-1 rounded">{t.repeat_cycle === "daily" ? "일간" : "주간"}</span>
                        <span className="font-bold text-zinc-200 truncate">{t.name}</span>
                      </div>
                      <div className="text-[10px] text-zinc-500 font-mono mt-0.5">Max: {t.max_count}회</div>
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      <button onClick={() => setEditingItem({ type: "task", data: { ...t } })} className="px-2 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded text-[11px] cursor-pointer">수정</button>
                      <button onClick={() => handleDeleteTask(t.id)} className="px-2 py-1 bg-rose-950/60 hover:bg-rose-900 text-rose-400 rounded text-[11px] cursor-pointer">삭제</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="space-y-2 pt-2 border-t border-zinc-800/80">
              <div className="flex gap-1.5">
                <select value={newRepeatCycle} onChange={(e: any) => setNewRepeatCycle(e.target.value)} className="bg-[#1c1c1e] border border-zinc-700 text-xs text-zinc-300 rounded-lg px-2 outline-none cursor-pointer">
                  <option value="weekly">주간 반복</option>
                  <option value="daily">일간 반복</option>
                </select>
                <input type="number" min="1" max="99" value={newRepeatMax} onChange={(e) => setNewRepeatMax(Number(e.target.value))} className="w-14 bg-[#1c1c1e] border border-zinc-700 rounded-lg p-1.5 text-xs text-center text-zinc-200 outline-none" />
              </div>
              <div className="flex gap-1.5">
                <input type="text" placeholder="새 반복 숙제" value={newRepeatName} onChange={(e) => setNewRepeatName(e.target.value)} className="flex-1 bg-[#1c1c1e] border border-zinc-700 rounded-lg px-2.5 py-2 text-xs text-zinc-200 outline-none focus:border-[#e6c788]" />
                <button onClick={() => handleAddTask("repeat", newRepeatName, newRepeatMax, newRepeatCycle)} className="px-3 bg-purple-500/20 hover:bg-purple-500/30 text-purple-400 font-bold rounded-lg text-xs border border-purple-500/40 cursor-pointer">+</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 2. 레이드 / 어비스 목록 설정 (nexus_contents 실시간 DB 바인딩) */}
      {!loading && subTab === "dungeons" && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* 어비스 관리 */}
          <div className="bg-[#121212] border border-zinc-800 rounded-xl p-4 space-y-4">
            <h3 className="text-sm font-bold text-teal-400 flex items-center gap-1.5">🔮 어비스 관리</h3>
            <div className="space-y-2.5 max-h-[350px] overflow-y-auto pr-1">
              {dungeons.filter((d) => d.type === "abyss").map((d) => (
                <div key={d.id} className="bg-[#1c1c1e] p-3 rounded-lg border border-zinc-800 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-zinc-200">{d.name}</span>
                    {d.is_weekend && (
                      <span className="px-1.5 py-0.5 bg-amber-500/20 text-amber-400 border border-amber-500/30 text-[10px] rounded font-semibold">주말</span>
                    )}
                  </div>
                  <div className="flex items-center gap-1">
                    <button onClick={() => setEditingItem({ type: "dungeon", data: { ...d } })} className="px-2.5 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded text-[11px] cursor-pointer">수정</button>
                    <button onClick={() => handleDeleteDungeon(d.id)} className="px-2.5 py-1 bg-rose-950/60 hover:bg-rose-900 text-rose-400 rounded text-[11px] cursor-pointer">삭제</button>
                  </div>
                </div>
              ))}
            </div>
            <div className="flex gap-2 pt-2 border-t border-zinc-800/80">
              <input type="text" placeholder="새 어비스 던전명" value={newAbyssName} onChange={(e) => setNewAbyssName(e.target.value)} className="flex-1 bg-[#1c1c1e] border border-zinc-700 rounded-lg px-3 py-2 text-xs text-zinc-200 outline-none focus:border-[#e6c788]" />
              <button onClick={() => handleAddDungeon("abyss", newAbyssName)} className="px-4 bg-teal-500/20 hover:bg-teal-500/30 text-teal-400 font-bold rounded-lg text-xs border border-teal-500/40 cursor-pointer">+</button>
            </div>
          </div>

          {/* 레이드 관리 */}
          <div className="bg-[#121212] border border-zinc-800 rounded-xl p-4 space-y-4">
            <h3 className="text-sm font-bold text-indigo-400 flex items-center gap-1.5">🐉 레이드 관리</h3>
            <div className="space-y-2.5 max-h-[350px] overflow-y-auto pr-1">
              {dungeons.filter((d) => d.type === "raid").map((d) => (
                <div key={d.id} className="bg-[#1c1c1e] p-3 rounded-lg border border-zinc-800 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-zinc-200">{d.name}</span>
                    {d.is_weekend && (
                      <span className="px-1.5 py-0.5 bg-amber-500/20 text-amber-400 border border-amber-500/30 text-[10px] rounded font-semibold">주말</span>
                    )}
                  </div>
                  <div className="flex items-center gap-1">
                    <button onClick={() => setEditingItem({ type: "dungeon", data: { ...d } })} className="px-2.5 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded text-[11px] cursor-pointer">수정</button>
                    <button onClick={() => handleDeleteDungeon(d.id)} className="px-2.5 py-1 bg-rose-950/60 hover:bg-rose-900 text-rose-400 rounded text-[11px] cursor-pointer">삭제</button>
                  </div>
                </div>
              ))}
            </div>
            <div className="flex gap-2 pt-2 border-t border-zinc-800/80">
              <input type="text" placeholder="새 레이드 던전명" value={newRaidName} onChange={(e) => setNewRaidName(e.target.value)} className="flex-1 bg-[#1c1c1e] border border-zinc-700 rounded-lg px-3 py-2 text-xs text-zinc-200 outline-none focus:border-[#e6c788]" />
              <button onClick={() => handleAddDungeon("raid", newRaidName)} className="px-4 bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-400 font-bold rounded-lg text-xs border border-indigo-500/40 cursor-pointer">+</button>
            </div>
          </div>
        </div>
      )}

      {/* 3. 클래스 목록 설정 */}
      {!loading && subTab === "classes" && (
        <div className="space-y-4">
          <div className="bg-[#121212] border border-zinc-800 rounded-xl p-4 space-y-4">
            <h3 className="text-sm font-bold text-[#e6c788]">🪖 클래스 레벨 관리 목록 설정</h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 max-h-[480px] overflow-y-auto pr-1">
              {classes.map((c) => (
                <div key={c.id} className="bg-[#1c1c1e] border border-zinc-800 hover:border-zinc-700 p-3 rounded-xl flex items-center justify-between gap-2 text-xs">
                  <div className="flex items-center gap-2 min-w-0">
                    <ClassIcon job={c.name} className="w-5 h-5 shrink-0" />
                    <span className="font-bold text-zinc-200 truncate">{c.name}</span>
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    <button onClick={() => setEditingItem({ type: "class", data: { ...c } })} className="text-zinc-500 hover:text-zinc-300 text-[11px] cursor-pointer">수정</button>
                    <button onClick={() => handleDeleteClass(c.id)} className="text-rose-500 hover:text-rose-400 text-[11px] cursor-pointer">삭제</button>
                  </div>
                </div>
              ))}

              {/* 신규 직업 추가 카드 */}
              <div className="bg-[#1c1c1e]/50 border border-dashed border-zinc-700 p-2.5 rounded-xl flex items-center gap-2">
                <input type="text" placeholder="직업명" value={newClassName} onChange={(e) => setNewClassName(e.target.value)} className="w-full bg-[#121212] border border-zinc-700 text-xs text-zinc-200 rounded px-2 py-1 outline-none" />
                <button onClick={handleAddClass} className="px-2.5 py-1 bg-[#e6c788] text-black font-bold text-xs rounded shrink-0 cursor-pointer">+</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 수정 모달 팝업 */}
      {editingItem && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
          <div className="bg-[#1c1c1e] border border-zinc-700 rounded-2xl p-6 w-full max-w-md space-y-4">
            <h3 className="text-base font-bold text-[#e6c788]">
              ✏️ {editingItem.type === "task" ? "숙제 항목 수정" : editingItem.type === "dungeon" ? "던전 수정" : "직업 수정"}
            </h3>

            <div className="space-y-3">
              <div>
                <label className="block text-xs text-zinc-400 mb-1">명칭</label>
                <input
                  type="text"
                  value={editingItem.data.name}
                  onChange={(e) => setEditingItem({ ...editingItem, data: { ...editingItem.data, name: e.target.value } })}
                  className="w-full bg-[#121212] border border-zinc-700 text-xs text-zinc-200 rounded-lg p-2.5 outline-none"
                />
              </div>

              {editingItem.type === "task" && (
                <div>
                  <label className="block text-xs text-zinc-400 mb-1">Max 횟수</label>
                  <input
                    type="number"
                    value={editingItem.data.max_count}
                    onChange={(e) => setEditingItem({ ...editingItem, data: { ...editingItem.data, max_count: Number(e.target.value) } })}
                    className="w-full bg-[#121212] border border-zinc-700 text-xs text-zinc-200 rounded-lg p-2.5 outline-none"
                  />
                </div>
              )}

              {editingItem.type === "class" && (
                <div>
                  <label className="block text-xs text-zinc-400 mb-1">역할군</label>
                  <select
                    value={editingItem.data.role}
                    onChange={(e: any) => setEditingItem({ ...editingItem, data: { ...editingItem.data, role: e.target.value } })}
                    className="w-full bg-[#121212] border border-zinc-700 text-xs text-zinc-200 rounded-lg p-2.5 outline-none cursor-pointer"
                  >
                    <option value="근딜">근딜</option>
                    <option value="원딜">원딜</option>
                    <option value="탱커">탱커</option>
                    <option value="힐러">힐러</option>
                    <option value="서포터">서포터</option>
                  </select>
                </div>
              )}
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button onClick={() => setEditingItem(null)} className="px-4 py-2 bg-zinc-800 text-zinc-400 rounded-lg text-xs font-bold cursor-pointer">취소</button>
              <button onClick={handleSaveEdit} className="px-4 py-2 bg-[#e6c788] text-black rounded-lg text-xs font-bold cursor-pointer">저장하기</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}