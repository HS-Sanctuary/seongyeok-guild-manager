"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";

// 실제 존재 확인된 7개 모듈 컴포넌트 매핑
import AccountApprovalTab from "./components/AccountApprovalTab";
import BannerAdminTab from "./components/BannerAdminTab";
import ClassTitleAdminTab from "./components/ClassTitleAdminTab";
import GnosisAdminTab from "./components/GnosisAdminTab";
import KronosAdminTab from "./components/KronosAdminTab";
import MissionAdminTab from "./components/MissionAdminTab";
import SynaxisAdminTab from "./components/SynaxisAdminTab";

const MAIN_TABS = [
  { id: "approval", label: "👥 가입 승인 & 권한 관리" },
  { id: "banner", label: "🚨 긴급 공지 배너" },
  { id: "kronos", label: "⚔️ 크로노스 숙제 & 거래" },
  { id: "mission", label: "📜 임무 게시판 관리" },
  { id: "synaxis", label: "🚌 시낙시스 & 버스 스탯" },
  { id: "class_title", label: "🛡️ 클래스 & 칭호 관리" },
  { id: "gnosis", label: "📖 그노시스 공략 관리" },
];

export default function AdminPage() {
  const router = useRouter();
  const [mounted, setMounted] = useState(false);
  const [user, setUser] = useState<any>(null);
  const [activeMainTab, setActiveMainTab] = useState("approval");

  useEffect(() => {
    setMounted(true);
    const savedUser = localStorage.getItem("nexus_user");
    if (!savedUser) {
      router.push("/login");
      return;
    }
    const parsedUser = JSON.parse(savedUser);

    const isAdmin =
      parsedUser.nickname === "한설" ||
      parsedUser.role === "길드마스터" ||
      parsedUser.role === "부마스터" ||
      parsedUser.role === "부마스터 대행" ||
      parsedUser.role === "admin" ||
      parsedUser.role === "master";

    if (!isAdmin) {
      alert("관리자 권한이 필요합니다.");
      router.push("/");
      return;
    }
    setUser(parsedUser);
  }, [router]);

  if (!mounted || !user) return null;

  return (
    <main className="min-h-screen bg-[#121212] text-[#d4d4d8] font-sans pb-20 pt-8">
      <div className="max-w-[1200px] mx-auto p-4 md:p-8 space-y-6">
        {/* 헤더 */}
        <div className="flex items-center gap-4 border-b border-zinc-800 pb-6">
          <div className="text-4xl">⚙️</div>
          <div>
            <h1 className="text-2xl md:text-3xl font-black text-[#e6c788]">
              성역 넥서스 통합 관제 센터
            </h1>
            <p className="text-sm text-zinc-400 mt-1">
              SANCTUM 길드 플랫폼의 가입 승인, 데이터 카탈로그 및 파티 버스를 제어합니다.
            </p>
          </div>
        </div>

        {/* 탭 네비게이션 */}
        <div className="flex gap-2 flex-wrap">
          {MAIN_TABS.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveMainTab(tab.id)}
              className={`px-4 py-2.5 rounded-xl text-xs md:text-sm font-bold transition-all cursor-pointer ${
                activeMainTab === tab.id
                  ? "bg-[#1c1c1e] text-[#e6c788] border border-zinc-700 shadow-md"
                  : "bg-transparent text-zinc-500 hover:bg-zinc-800/50 hover:text-zinc-300"
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* 독립 모듈 렌더링 영역 */}
        <div className="bg-[#1c1c1e] border border-zinc-800 rounded-2xl p-6 shadow-xl min-h-[550px]">
          {activeMainTab === "approval" && <AccountApprovalTab currentUser={user} />}
          {activeMainTab === "banner" && <BannerAdminTab />}
          {activeMainTab === "kronos" && <KronosAdminTab />}
          {activeMainTab === "mission" && <MissionAdminTab />}
          {activeMainTab === "synaxis" && <SynaxisAdminTab />}
          {activeMainTab === "class_title" && <ClassTitleAdminTab />}
          {activeMainTab === "gnosis" && <GnosisAdminTab />}
        </div>
      </div>
    </main>
  );
}